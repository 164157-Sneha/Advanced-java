package SpringProject.assignment2_spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sneha.asgn.Question;

public class TestAnswer {

	public static void main(String[] args) {
		
		 ApplicationContext context =new ClassPathXmlApplicationContext("springques.xml");
	       
	       Question ans= context.getBean(Question.class);
	       
	       ans.display();
	       
	    }
 
	}


