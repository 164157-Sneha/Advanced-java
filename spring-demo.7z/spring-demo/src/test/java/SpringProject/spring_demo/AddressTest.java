package SpringProject.spring_demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sneha.app.ConstructorCustomer;



public class AddressTest {

	public static void main(String[] args) {
		 ApplicationContext context =new ClassPathXmlApplicationContext("springcon.xml");
	       
	      ConstructorCustomer cust= context.getBean(ConstructorCustomer.class);
	      cust.display();

	}

}
