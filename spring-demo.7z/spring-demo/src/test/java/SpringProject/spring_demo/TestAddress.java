package SpringProject.spring_demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sneha.app.Address;
import com.sneha.app.Customer;
//import com.sneha.helloclass.HelloWorld;

public class TestAddress {

	public static void main(String[] args) {
		 ApplicationContext context =new ClassPathXmlApplicationContext("spring.xml");
	       
	      Customer cust= context.getBean(Customer.class);
	      cust.display_address();

	}

}
