package com.sneha.app;

public class constructorAddress {

	private String street;
	private String city;
	private int zip;
	private String country;
	private String state;
	
	
	public constructorAddress(String street, String city, int zip,
			String country, String state) {
		super();
		this.street = street;
		this.city = city;
		this.zip = zip;
		this.country = country;
		this.state = state;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}


	@Override
	public String toString() {
		return "constructorAddress [street=" + street + ", city=" + city
				+ ", zip=" + zip + ", country=" + country + ", state=" + state
				+ "]";
	}
	
	
	
}
