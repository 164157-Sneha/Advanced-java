package com.sneha.app;

public class ConstructorCustomer {

	private int id;
	private String name;
	private int contact;
	private constructorAddress address;
	
	
	
	public ConstructorCustomer(int id, String name, int contact,
			constructorAddress address) {
		super();
		this.id = id;
		this.name = name;
		this.contact = contact;
		this.address = address;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getContact() {
		return contact;
	}


	public void setContact(int contact) {
		this.contact = contact;
	}


	


	public constructorAddress getAddress() {
		return address;
	}


	public void setAddress(constructorAddress address) {
		this.address = address;
	}


	public void display()
	{
		System.out.println(getId()+ " "+getName()+" "+getContact()+" "+getAddress());
	}
	
	
}
