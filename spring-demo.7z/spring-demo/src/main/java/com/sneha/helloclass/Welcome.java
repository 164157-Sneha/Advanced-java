package com.sneha.helloclass;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Welcome {

	public static void main(String[] args) {
		
		ApplicationContext context =new ClassPathXmlApplicationContext("spring.xml");
	       HelloWorld hi= context.getBean(HelloWorld.class);
	       hi.display();

	}

}
