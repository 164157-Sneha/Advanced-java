package com.sneha.helloclass;

public class HelloWorld {

	public void display(){
		System.out.println("Welcome to Capgemini");
	}
}
