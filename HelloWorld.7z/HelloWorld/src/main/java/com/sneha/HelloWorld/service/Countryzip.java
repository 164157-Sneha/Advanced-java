package com.sneha.HelloWorld.service;

import java.util.HashMap;
import java.util.Map;

import com.sneha.HelloWorld.model.CountryClass;

public class Countryzip {

	public Map<Integer,CountryClass> zip = new HashMap<>(); 
	
	public Map<Integer, CountryClass> Countryzip()
	{
	zip.put(123,new CountryClass("Karnataka","Bangalore","India"));
	zip.put(561,new CountryClass("Kerala","Cochin","India"));
	zip.put(789,new CountryClass("Kashmir","Srinagar","India"));
	
	return zip;
	}
}
