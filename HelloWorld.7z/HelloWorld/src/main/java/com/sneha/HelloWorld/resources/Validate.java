package com.sneha.HelloWorld.resources;

import java.util.Map;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sneha.HelloWorld.model.CountryClass;
import com.sneha.HelloWorld.service.Countryzip;


@Path("/zipcod")
public class Validate {

			Countryzip con= new Countryzip();
			@Path("{zipcode}")
		     @POST		
		     @Produces(MediaType.APPLICATION_JSON)
			public CountryClass test(@PathParam ("zipcode") int zipcode)
			{
		    	 for (Map.Entry<Integer,CountryClass> entry : con.Countryzip().entrySet())  
		         if(zipcode == entry.getKey())
		         {
		        	return entry.getValue(); 
			}
		     return null;
}
}


