package com.sneha.HelloWorld.resources;

import java.util.List;

import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.sneha.HelloWorld.model.Employees;
import com.sneha.HelloWorld.service.EmployeeService;


@Path("/emp")

public class EmpResource {

	EmployeeService empService= new EmployeeService();
	
    @GET
     @Produces(MediaType.APPLICATION_JSON)
	 public List<Employees> getEmployees() 
     {
		
    	 return empService.getAllEmployees();
     }

    /* @POST
     @Consumes(MediaType.APPLICATION_JSON)
     @Produces(MediaType.APPLICATION_JSON)
     public Employees addEmployees(Employees empl)
     {
    	return empService.addEmployee(empl);
     }
     
     @PUT
     @Path("/{employeeId}")
     @Consumes(MediaType.APPLICATION_JSON)
     @Produces(MediaType.APPLICATION_JSON)
     public Employees updateEmployees(@PathParam("employeeId")int employeeId,Employees empl)
     {
    	empl.setEmployeeId(employeeId);
     	return empService.updateEmployees(empl);
     }
     
     
     @GET
     @Path("/{employeeId}")
     @Produces(MediaType.APPLICATION_JSON)
     public Employees getEmployees(@PathParam("employeeId")int employeeId) {
 		return empService.getEmployees(employeeId);
 	}
     */
    
     
}


	

