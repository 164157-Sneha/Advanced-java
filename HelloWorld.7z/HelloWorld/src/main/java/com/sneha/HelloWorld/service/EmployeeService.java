package com.sneha.HelloWorld.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sneha.HelloWorld.database.EmployeeData;
import com.sneha.HelloWorld.model.Employees;
import com.sneha.HelloWorld.model.Message;

public class EmployeeService {

	private Map<Integer,Employees> empl = EmployeeData.getEmployees();
	
	
	public EmployeeService() {
		
		empl.put(1, new Employees(1,"Sneha",15,"Analyst",15000));
		empl.put(2, new Employees(2,"Sana",10,"Manager",45000));
		empl.put(3, new Employees(3,"Sonali",16,"Developer",25000));
	}
	
public List<Employees> getAllEmployees(){
		
		return new ArrayList<Employees> (empl.values());
	}

	public Employees getEmployees(int employeeId) {
		return empl.get(employeeId);
	}
	
	public Employees addEmployee(Employees empl) {
	    ((Map<Integer, Employees>) empl).put(empl.getEmployeeId(), empl);
		return empl;
	}
	
	public Employees updateEmployees(Employees empl) 
	{
		if(empl.getEmployeeId()<=0)
		{
			return null;
		}
		
		((Map<Integer, Employees>) empl).put(empl.getEmployeeId(), empl);
	return empl;
}
	
public Employees removeEmployees(int  employeeId)
{
	return empl.remove(employeeId);
}
	
}
