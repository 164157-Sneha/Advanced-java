package com.sneha.HelloWorld.database;

import java.util.HashMap;
import java.util.Map;

import com.sneha.HelloWorld.model.Employees;

public class EmployeeData {

	public static Map<Integer,Employees> emp = new HashMap<>();
	
	public static Map<Integer, Employees> getEmployees()
	{
    	return emp;
    }
}
