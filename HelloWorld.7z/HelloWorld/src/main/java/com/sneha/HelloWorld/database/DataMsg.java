package com.sneha.HelloWorld.database;

import java.util.HashMap;
import java.util.Map;

public class DataMsg {

	private static Map<String, String> user = new HashMap<>();

	public static Map<String, String> getUser() {
		return user;
	}

	public static void setUser(Map<String, String> user) {
		DataMsg.user = user;
	}
	
	
}
