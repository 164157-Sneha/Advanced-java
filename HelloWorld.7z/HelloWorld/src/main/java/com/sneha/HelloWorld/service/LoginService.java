package com.sneha.HelloWorld.service;

import java.util.Map;

import com.sneha.HelloWorld.database.DataMsg;


public class LoginService {

	public Map<String,String> user = DataMsg.getUser();
	
	
//	public LoginService()
//	{
//		user.put("Sneha", "Kashyap");
//		user.put("Chaya", "1234");
//		user.put("Rashmi", "Halli");
//	}
	
   public String getUser(String username, String password) {
	   
	   if(username.equals("Sneha") && password.equals("Kashyap") )
	   {
		   return "validated";
	   }
	   else
	   {
		   return "Invalid";
	   }
	  
}
}